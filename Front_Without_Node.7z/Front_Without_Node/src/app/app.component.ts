import { Component } from "@angular/core";
import { InventoryServiceService } from "./inventory-service.service";
import { product } from "./product";
@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {
  

product : product;
  constructor(private merchantService: InventoryServiceService) {
    
  }
show:boolean=false;

  showProducts(data) {
  
    this.merchantService.showProducts(data.mid).subscribe(data1 => {this.product = data1;
    alert("press ok to display products"); this.show=true;
    });
  }

}
